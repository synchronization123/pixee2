// DefectDojo Engagement Manager v1.0.11
// Complete JavaScript with all features

// Global variables
let currentPage = 1;
let pageSize = 10;
let totalCount = 0;
let currentEngagements = [];

let jiraCurrentPage = 1;
let jiraPageSize = 10;
let jiraTotalCount = 0;
let currentTests = [];
let currentTest = null;

let allUsers = [];
let allProducts = [];
let allEnvironments = [];
let allEngagements = [];

let filterOptions = {
    assignedTo: [],
    mentorStatus: [],
    leadStatus: [],
    products: []
};

let jiraFilterOptions = {
    jiraStatus: [],
    jiraType: [],
    analysisStatus: [],
    assignedTo: [],
    buildType: [],
    task: []
};

const JIRA_CACHE_KEY = 'defectdojo_jira_counts';
const CACHE_VERSION_KEY = 'defectdojo_jira_cache_version';
const CACHE_VERSION = '1.0';

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    showLoadingModal('Loading Engagements...');
    initializeCache();
    loadFilterOptions().then(() => {
        loadEngagements();
    });
    setupEventListeners();
});

// Cache management
function initializeCache() {
    try {
        const version = localStorage.getItem(CACHE_VERSION_KEY);
        if (version !== CACHE_VERSION) {
            localStorage.removeItem(JIRA_CACHE_KEY);
            localStorage.setItem(CACHE_VERSION_KEY, CACHE_VERSION);
        }
    } catch (e) {
        console.error('Cache initialization error:', e);
    }
}

function getCachedJiraCounts() {
    try {
        const cached = localStorage.getItem(JIRA_CACHE_KEY);
        return cached ? JSON.parse(cached) : {};
    } catch (e) {
        return {};
    }
}

function saveToCache(counts) {
    try {
        const cached = getCachedJiraCounts();
        Object.assign(cached, counts);
        localStorage.setItem(JIRA_CACHE_KEY, JSON.stringify(cached));
    } catch (e) {
        console.error('Cache save error:', e);
    }
}

// Event listeners setup
function setupEventListeners() {
    // Main page events
    document.getElementById('pageSize')?.addEventListener('change', () => {
        pageSize = parseInt(document.getElementById('pageSize').value);
        currentPage = 1;
        loadEngagements();
    });

    document.getElementById('goBtn')?.addEventListener('click', () => {
        currentPage = 1;
        showLoadingModal('Loading...');
        loadEngagements();
    });

    document.getElementById('clearFiltersBtn')?.addEventListener('click', () => {
        clearAllFilters();
        currentPage = 1;
        showLoadingModal('Loading...');
        loadEngagements();
    });

    document.getElementById('refreshBtn')?.addEventListener('click', () => {
        showLoadingModal('Refreshing...');
        loadEngagements();
    });

    document.getElementById('fetchJiraBtn')?.addEventListener('click', () => {
        fetchJiraCountsForCurrentPage();
    });

    document.getElementById('saveBtn')?.addEventListener('click', () => {
        saveEngagement();
    });

    document.getElementById('openJirasBtn')?.addEventListener('click', () => {
        openJirasModal();
    });

    document.getElementById('summaryBtn')?.addEventListener('click', () => {
        openSummaryModal();
    });

    // Jira modal events
    document.getElementById('jiraPageSize')?.addEventListener('change', () => {
        jiraPageSize = parseInt(document.getElementById('jiraPageSize').value);
        jiraCurrentPage = 1;
        loadTests();
    });

    document.getElementById('jiraGoBtn')?.addEventListener('click', () => {
        jiraCurrentPage = 1;
        showJiraTableLoading('Loading Jira Items...');
        loadTests();
    });

    document.getElementById('jiraClearBtn')?.addEventListener('click', () => {
        clearJiraFilters();
        jiraCurrentPage = 1;
        showJiraTableLoading('Clearing Filters...');
        loadTests();
    });

    document.getElementById('saveTestBtn')?.addEventListener('click', () => {
        saveTest();
    });

    // Summary modal events
    document.getElementById('summaryEngagements')?.addEventListener('change', function() {
        if (this.checked) {
            showSummaryLoading();
            loadEngagementsSummary();
        }
    });

    document.getElementById('summaryJiras')?.addEventListener('change', function() {
        if (this.checked) {
            showSummaryLoading();
            loadJirasSummary();
        }
    });
}

// Filter management
function clearAllFilters() {
    const filterIds = [
        'filterTaskName', 'filterAssignedTo', 'filterAnalysisStatus',
        'filterMentorStatus', 'filterLeadStatus', 'filterProduct',
        'filterCreatedFrom', 'filterCreatedTo', 'filterAppSecFrom',
        'filterAppSecTo', 'filterRMFrom', 'filterRMTo'
    ];

    filterIds.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });
}

function clearJiraFilters() {
    const filterIds = [
        'jiraFilterTitle', 'jiraFilterStatus', 'jiraFilterType',
        'jiraFilterAnalysis', 'jiraFilterAssigned', 'jiraFilterBuild',
        'jiraFilterTask'
    ];

    filterIds.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });
}

// Modal functions
function showLoadingModal(text) {
    const modalElement = document.getElementById('loadingModal');
    const textElement = document.getElementById('loadingModalText');
    if (textElement) textElement.textContent = text;
    const modal = bootstrap.Modal.getInstance(modalElement) || new bootstrap.Modal(modalElement);
    modal.show();
}

function hideLoadingModal() {
    const modalElement = document.getElementById('loadingModal');
    const modal = bootstrap.Modal.getInstance(modalElement);
    if (modal) modal.hide();
}

function showJiraTableLoading(text) {
    const tbody = document.getElementById('jirasTableBody');
    tbody.innerHTML = `
        <tr>
            <td colspan="10" class="text-center py-4">
                <div class="spinner-border text-primary mb-2" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <div class="fw-bold">${text}</div>
                <div class="text-muted">Please wait...</div>
            </td>
        </tr>
    `;
}

function showSummaryLoading() {
    document.getElementById('summaryTableBody').innerHTML = `
        <tr>
            <td colspan="20" class="text-center py-4">
                <div class="spinner-border text-primary mb-2"></div>
                <div class="fw-bold">Loading Summary...</div>
                <div class="text-muted">Please wait...</div>
            </td>
        </tr>
    `;
    document.querySelector('#summaryTable thead').innerHTML = '';
}

function showToast(message) {
    const toastElement = document.getElementById('successToast');
    const toastMessage = document.getElementById('toastMessage');
    toastMessage.textContent = message;
    const toast = new bootstrap.Toast(toastElement, {autohide: true, delay: 3000});
    toast.show();
}

// Load filter options
async function loadFilterOptions() {
    try {
        const response = await fetch('/api/filter-options');
        const result = await response.json();

        if (result.success) {
            filterOptions.assignedTo = result.assigned_to || [];
            filterOptions.mentorStatus = result.mentor_status || [];
            filterOptions.leadStatus = result.lead_status || [];
            filterOptions.products = result.products || [];

            allUsers = filterOptions.assignedTo;
            allProducts = filterOptions.products;

            populateDropdown('filterAssignedTo', filterOptions.assignedTo, 'name', 'id');
            populateDropdown('filterMentorStatus', filterOptions.mentorStatus);
            populateDropdown('filterLeadStatus', filterOptions.leadStatus);
            populateDropdown('filterProduct', filterOptions.products, 'name', 'id');
        }
    } catch (error) {
        console.error('Error loading filter options:', error);
    }
}

async function loadAllUsers() {
    try {
        const response = await fetch('/api/filter-options');
        const result = await response.json();
        if (result.success) {
            allUsers = result.assigned_to || [];
        }
    } catch (error) {
        console.error('Error loading users:', error);
    }
}

async function loadTestFilterOptions() {
    try {
        const response = await fetch('/api/test-filter-options');
        const result = await response.json();

        if (result.success) {
            jiraFilterOptions.jiraStatus = result.jira_status || [];
            jiraFilterOptions.jiraType = result.jira_type || [];
            jiraFilterOptions.analysisStatus = result.analysis_status || [];
            jiraFilterOptions.assignedTo = result.assigned_to || [];
            jiraFilterOptions.buildType = result.build_type || [];
            jiraFilterOptions.task = result.task || [];

            allEnvironments = jiraFilterOptions.buildType;
            allEngagements = jiraFilterOptions.task;

            populateDropdown('jiraFilterStatus', jiraFilterOptions.jiraStatus);
            populateDropdown('jiraFilterType', jiraFilterOptions.jiraType);
            populateDropdown('jiraFilterAnalysis', jiraFilterOptions.analysisStatus);
            populateDropdown('jiraFilterAssigned', jiraFilterOptions.assignedTo, 'name', 'id');
            populateDropdown('jiraFilterBuild', jiraFilterOptions.buildType, 'name', 'id');
            populateDropdown('jiraFilterTask', jiraFilterOptions.task, 'name', 'id');
        }
    } catch (error) {
        console.error('Error loading test filter options:', error);
    }
}

function populateDropdown(elementId, options, labelKey = null, valueKey = null) {
    const select = document.getElementById(elementId);
    if (!select) return;

    const currentValue = select.value;
    select.innerHTML = '<option value="">All</option>';

    options.forEach(option => {
        const opt = document.createElement('option');
        if (labelKey && valueKey) {
            opt.value = option[valueKey];
            opt.textContent = option[labelKey];
        } else {
            opt.value = option;
            opt.textContent = option;
        }
        select.appendChild(opt);
    });

    if (currentValue) select.value = currentValue;
}

// Get filter parameters
function getFilterParams() {
    const params = new URLSearchParams();
    params.append('page', currentPage);
    params.append('limit', pageSize);

    const filters = {
        'filterTaskName': 'task_name',
        'filterAssignedTo': 'assigned_to',
        'filterAnalysisStatus': 'status',
        'filterMentorStatus': 'mentor_status',
        'filterLeadStatus': 'lead_status',
        'filterProduct': 'product',
        'filterCreatedFrom': 'created_from',
        'filterCreatedTo': 'created_to',
        'filterAppSecFrom': 'appsec_eta_from',
        'filterAppSecTo': 'appsec_eta_to',
        'filterRMFrom': 'rm_eta_from',
        'filterRMTo': 'rm_eta_to'
    };

    Object.entries(filters).forEach(([id, param]) => {
        const el = document.getElementById(id);
        const value = el ? el.value.trim() : '';
        if (value) params.append(param, value);
    });

    return params;
}

function getJiraFilterParams() {
    const params = new URLSearchParams();
    params.append('page', jiraCurrentPage);
    params.append('limit', jiraPageSize);

    const filters = {
        'jiraFilterTitle': 'title',
        'jiraFilterStatus': 'jira_status',
        'jiraFilterType': 'jira_type',
        'jiraFilterAnalysis': 'analysis_status',
        'jiraFilterAssigned': 'assigned_to',
        'jiraFilterBuild': 'build_type',
        'jiraFilterTask': 'task'
    };

    Object.entries(filters).forEach(([id, param]) => {
        const el = document.getElementById(id);
        const value = el ? el.value.trim() : '';
        if (value) params.append(param, value);
    });

    return params;
}

// Load data
async function loadEngagements() {
    try {
        const params = getFilterParams();
        const response = await fetch(`/api/engagements?${params.toString()}`);
        const result = await response.json();

        if (result.success) {
            totalCount = result.total;
            currentEngagements = result.data;
            renderEngagements(result.data);
            renderPagination(result.total);
            updateTotalCount(result.total);
            loadCachedCounts();
        } else {
            showError(result.error || 'Failed to load engagements');
        }
    } catch (error) {
        showError('Network error: ' + error.message);
    } finally {
        hideLoadingModal();
    }
}

async function loadTests() {
    try {
        const params = getJiraFilterParams();
        const response = await fetch(`/api/tests?${params.toString()}`);
        const result = await response.json();

        if (result.success) {
            jiraTotalCount = result.total;
            currentTests = result.data;
            renderTests(result.data);
            renderJiraPagination(result.total);
            document.getElementById('jiraTotalCount').textContent = result.total;
        } else {
            showTestError(result.error || 'Failed to load tests');
        }
    } catch (error) {
        showTestError('Network error: ' + error.message);
    }
}

function loadCachedCounts() {
    const cached = getCachedJiraCounts();
    currentEngagements.forEach(eng => {
        const engId = String(eng.id);
        if (cached[engId]) {
            updateEngagementJiraCounts(engId, cached[engId]);
        }
    });
}

async function fetchJiraCountsForCurrentPage() {
    if (currentEngagements.length === 0) {
        showToast('No engagements to fetch counts for');
        return;
    }

    showLoadingModal('Fetching Jira Counts...');

    try {
        const engagementIds = currentEngagements.map(eng => eng.id);
        const response = await fetch('/api/jira-counts', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({engagement_ids: engagementIds})
        });

        const result = await response.json();

        if (result.success) {
            for (const [engId, counts] of Object.entries(result.counts)) {
                updateEngagementJiraCounts(engId, counts);
            }
            saveToCache(result.counts);
            showToast('Jira counts fetched and updated successfully!');
        } else {
            showError(result.error || 'Failed to fetch Jira counts');
        }
    } catch (error) {
        showError('Network error: ' + error.message);
    } finally {
        hideLoadingModal();
    }
}

function updateEngagementJiraCounts(engId, counts) {
    const rows = document.querySelectorAll('#engagementsBody tr');
    rows.forEach(row => {
        const idCell = row.querySelector('td:first-child');
        if (idCell && idCell.textContent === String(engId)) {
            const cells = row.querySelectorAll('td');
            if (cells.length >= 11) {
                cells[4].textContent = counts.T || 0;
                cells[5].textContent = counts.C || 0;
                cells[6].textContent = counts.P || 0;
                cells[7].textContent = counts.S || 0;
                cells[8].textContent = counts.F || 0;
                cells[9].textContent = counts.D || 0;
                cells[10].textContent = counts.ND || 0;
            }
        }
    });
}

// Date functions
function getTodayDate() {
    return new Date().toISOString().split('T')[0];
}

function isToday(dateStr) {
    return dateStr && dateStr !== 'N/A' && dateStr === getTodayDate();
}

function isPast(dateStr) {
    if (!dateStr || dateStr === 'N/A') return false;
    const date = new Date(dateStr);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    date.setHours(0, 0, 0, 0);
    return date < today;
}

// Render functions
function renderEngagements(engagements) {
    const tbody = document.getElementById('engagementsBody');

    if (engagements.length === 0) {
        tbody.innerHTML = '<tr><td colspan="21" class="text-center py-5">No engagements found</td></tr>';
        return;
    }

    tbody.innerHTML = '';

    engagements.forEach(eng => {
        const row = document.createElement('tr');

        const agingClass = eng.aging > 30 ? 'aging-high' : 
                          (eng.aging > 14 ? 'aging-medium' : 'aging-low');

        const statusBadge = getStatusBadge(eng.status);

        const appSecClass = isToday(eng.target_start) ? 'bg-red' : 
                           (isPast(eng.target_start) ? 'bg-light-maroon' : '');

        const rmEtaClass = isToday(eng.target_end) ? 'bg-red' : 
                          (isPast(eng.target_end) ? 'bg-light-maroon' : '');

        row.innerHTML = `
            <td>${eng.id}</td>
            <td>${eng.created}</td>
            <td class="${agingClass}">${eng.aging}</td>
            <td class="task-name">${eng.name}</td>
            <td class="text-center jira-count">0</td>
            <td class="text-center jira-count">0</td>
            <td class="text-center jira-count">0</td>
            <td class="text-center jira-count">0</td>
            <td class="text-center jira-count">0</td>
            <td class="text-center jira-count">0</td>
            <td class="text-center jira-count">0</td>
            <td>${eng.lead}</td>
            <td class="${appSecClass}">${eng.target_start}</td>
            <td class="${rmEtaClass}">${eng.target_end}</td>
            <td>${statusBadge}</td>
            <td>${eng.build_id || 'N/A'}</td>
            <td>${eng.commit_hash || 'N/A'}</td>
            <td>${eng.product}</td>
            <td>${eng.version || 'N/A'}</td>
            <td>${eng.updated}</td>
            <td class="text-center">
                <button class="btn btn-sm btn-primary" onclick="openEditModal(${eng.id})">
                    <i class="bi bi-pencil-square"></i>
                </button>
            </td>
        `;

        tbody.appendChild(row);
    });
}

function renderTests(tests) {
    const tbody = document.getElementById('jirasTableBody');

    if (tests.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" class="text-center py-3">No Jira items found</td></tr>';
        return;
    }

    tbody.innerHTML = '';

    tests.forEach(test => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${test.id}</td>
            <td>${test.created || 'N/A'}</td>
            <td>${test.title || 'N/A'}</td>
            <td>${test.branch_tag || 'N/A'}</td>
            <td>${test.commit_hash || 'N/A'}</td>
            <td>${test.build_id || 'N/A'}</td>
            <td>${test.lead || 'N/A'}</td>
            <td>${test.environment || 'N/A'}</td>
            <td>${test.engagement || 'N/A'}</td>
            <td class="text-center">
                <button class="btn btn-sm btn-primary" onclick="openEditTestModal(${test.id})">
                    <i class="bi bi-pencil-square"></i>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function getStatusBadge(status) {
    const badges = {
        'Not Started': 'status-not-started',
        'On Hold': 'status-on-hold',
        'In Progress': 'status-in-progress',
        'Completed': 'status-completed',
        'Cancelled': 'status-cancelled'
    };

    const badgeClass = 'status-badge ' + (badges[status] || 'bg-secondary text-white');
    return `<span class="${badgeClass}">${status}</span>`;
}

// Pagination
function renderPagination(total) {
    renderPaginationTo('paginationTop', Math.ceil(total / pageSize), currentPage, 'changePage');
}

function renderJiraPagination(total) {
    renderPaginationTo('jiraPagination', Math.ceil(total / jiraPageSize), jiraCurrentPage, 'changeJiraPage');
}

function renderPaginationTo(elementId, totalPages, currentPg, changeFunc) {
    const pagination = document.getElementById(elementId);

    if (!pagination || totalPages <= 1) {
        if (pagination) pagination.innerHTML = '';
        return;
    }

    let html = '';

    html += `<li class="page-item ${currentPg === 1 ? 'disabled' : ''}">
        <a class="page-link" href="#" onclick="${changeFunc}(1); return false;">First</a>
    </li>`;

    html += `<li class="page-item ${currentPg === 1 ? 'disabled' : ''}">
        <a class="page-link" href="#" onclick="${changeFunc}(${currentPg - 1}); return false;">Prev</a>
    </li>`;

    const startPage = Math.max(1, currentPg - 2);
    const endPage = Math.min(totalPages, currentPg + 2);

    if (startPage > 1) {
        html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
    }

    for (let i = startPage; i <= endPage; i++) {
        html += `<li class="page-item ${i === currentPg ? 'active' : ''}">
            <a class="page-link" href="#" onclick="${changeFunc}(${i}); return false;">${i}</a>
        </li>`;
    }

    if (endPage < totalPages) {
        html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
    }

    html += `<li class="page-item ${currentPg === totalPages ? 'disabled' : ''}">
        <a class="page-link" href="#" onclick="${changeFunc}(${currentPg + 1}); return false;">Next</a>
    </li>`;

    html += `<li class="page-item ${currentPg === totalPages ? 'disabled' : ''}">
        <a class="page-link" href="#" onclick="${changeFunc}(${totalPages}); return false;">Last</a>
    </li>`;

    pagination.innerHTML = html;
}

function changePage(page) {
    if (page < 1 || page > Math.ceil(totalCount / pageSize)) return;
    currentPage = page;
    showLoadingModal('Loading Page...');
    loadEngagements();
}

function changeJiraPage(page) {
    if (page < 1 || page > Math.ceil(jiraTotalCount / jiraPageSize)) return;
    jiraCurrentPage = page;
    showJiraTableLoading('Loading Page...');
    loadTests();
}

function updateTotalCount(total) {
    document.getElementById('totalCount').textContent = total;
}

// Error handling
function showError(message) {
    document.getElementById('engagementsBody').innerHTML = `
        <tr>
            <td colspan="21" class="text-center py-4">
                <div class="alert alert-danger">
                    <strong>Error:</strong> ${message}
                </div>
            </td>
        </tr>
    `;
}

function showTestError(message) {
    document.getElementById('jirasTableBody').innerHTML = `
        <tr>
            <td colspan="10" class="text-center py-4">
                <div class="alert alert-danger">
                    <strong>Error:</strong> ${message}
                </div>
            </td>
        </tr>
    `;
}

function showSummaryError(message) {
    document.getElementById('summaryTableBody').innerHTML = `
        <tr>
            <td colspan="20" class="text-center py-4">
                <div class="alert alert-danger">
                    <strong>Error:</strong> ${message}
                </div>
            </td>
        </tr>
    `;
}

// Edit engagement modal
function openEditModal(engagementId) {
    const engagement = currentEngagements.find(e => e.id === engagementId);
    if (!engagement) return;

    document.getElementById('editId').value = engagement.id;
    document.getElementById('editCreated').value = engagement.created;
    document.getElementById('editAging').value = engagement.aging + ' days';
    document.getElementById('editTaskName').value = engagement.name;
    document.getElementById('editProductName').value = engagement.product;
    document.getElementById('editProductId').value = engagement.product_id;

    const assignedToSelect = document.getElementById('editAssignedTo');
    assignedToSelect.innerHTML = '<option value="">Select User</option>';
    allUsers.forEach(user => {
        const option = document.createElement('option');
        option.value = user.id;
        option.textContent = user.name;
        if (user.id === engagement.lead_id) option.selected = true;
        assignedToSelect.appendChild(option);
    });

    document.getElementById('editAppSecETA').value = engagement.target_start !== 'N/A' ? engagement.target_start : '';
    document.getElementById('editRMETA').value = engagement.target_end !== 'N/A' ? engagement.target_end : '';
    document.getElementById('editAnalysisStatus').value = engagement.status;
    document.getElementById('editMentorStatus').value = engagement.build_id !== 'N/A' ? engagement.build_id : '';
    document.getElementById('editLeadStatus').value = engagement.commit_hash !== 'N/A' ? engagement.commit_hash : '';
    document.getElementById('editVersion').value = engagement.version !== 'N/A' ? engagement.version : '';
    document.getElementById('editDescription').value = engagement.description || '';

    const modal = new bootstrap.Modal(document.getElementById('editModal'));
    modal.show();
}

async function saveEngagement() {
    const engagementId = document.getElementById('editId').value;
    const assignedTo = document.getElementById('editAssignedTo').value;
    const appSecETA = document.getElementById('editAppSecETA').value;
    const rmETA = document.getElementById('editRMETA').value;

    if (!assignedTo || !appSecETA || !rmETA) {
        alert('Please fill all required fields');
        return;
    }

    document.getElementById('saveBtnText').classList.add('d-none');
    document.getElementById('saveBtnSpinner').classList.remove('d-none');
    document.getElementById('saveBtn').disabled = true;

    try {
        const payload = {
            name: document.getElementById('editTaskName').value,
            target_start: appSecETA,
            target_end: rmETA,
            lead: assignedTo,
            product: document.getElementById('editProductId').value,
            status: document.getElementById('editAnalysisStatus').value,
            build_id: document.getElementById('editMentorStatus').value,
            commit_hash: document.getElementById('editLeadStatus').value,
            version: document.getElementById('editVersion').value,
            description: document.getElementById('editDescription').value
        };

        const response = await fetch(`/api/engagement/${engagementId}`, {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });

        const result = await response.json();

        if (result.success) {
            showToast('Engagement updated successfully!');
            bootstrap.Modal.getInstance(document.getElementById('editModal')).hide();
            loadEngagements();
        } else {
            alert('Error: ' + (result.error || 'Failed to update'));
        }
    } catch (error) {
        alert('Network error: ' + error.message);
    } finally {
        document.getElementById('saveBtnText').classList.remove('d-none');
        document.getElementById('saveBtnSpinner').classList.add('d-none');
        document.getElementById('saveBtn').disabled = false;
    }
}

// Jiras modal
async function openJirasModal() {
    showLoadingModal('Loading Jiras Modal...');

    try {
        await Promise.all([loadTestFilterOptions(), loadAllUsers()]);
        const modal = new bootstrap.Modal(document.getElementById('jirasModal'));
        modal.show();
    } catch (error) {
        console.error('Error opening Jiras modal:', error);
    } finally {
        hideLoadingModal();
    }
}

function openEditTestModal(testId) {
    currentTest = currentTests.find(t => t.id === testId);
    if (!currentTest) return;

    document.getElementById('editTestId').value = currentTest.id;
    document.getElementById('editTestTitle').value = currentTest.title;
    document.getElementById('editTestAnalysis').value = currentTest.build_id || 'Pending';

    const assignedSelect = document.getElementById('editTestAssigned');
    assignedSelect.innerHTML = '<option value="">Select</option>';
    allUsers.forEach(user => {
        const option = document.createElement('option');
        option.value = user.id;
        option.textContent = user.name;
        if (user.id === currentTest.lead_id) option.selected = true;
        assignedSelect.appendChild(option);
    });

    const buildSelect = document.getElementById('editTestBuild');
    buildSelect.innerHTML = '<option value="">Select</option>';
    allEnvironments.forEach(env => {
        const option = document.createElement('option');
        option.value = env.id;
        option.textContent = env.name;
        if (env.id === currentTest.environment_id) option.selected = true;
        buildSelect.appendChild(option);
    });

    const modal = new bootstrap.Modal(document.getElementById('editTestModal'));
    modal.show();
}

async function saveTest() {
    const testId = document.getElementById('editTestId').value;
    const assigned = document.getElementById('editTestAssigned').value;
    const build = document.getElementById('editTestBuild').value;

    if (!assigned || !build) {
        alert('Please fill all required fields');
        return;
    }

    document.getElementById('saveTestBtnText').classList.add('d-none');
    document.getElementById('saveTestBtnSpinner').classList.remove('d-none');
    document.getElementById('saveTestBtn').disabled = true;

    try {
        const payload = {
            title: currentTest.title,
            target_start: currentTest.target_start,
            target_end: currentTest.target_end,
            test_type_name: currentTest.test_type_name,
            engagement: currentTest.engagement_id,
            lead: parseInt(assigned),
            test_type: currentTest.test_type,
            environment: parseInt(build),
            build_id: document.getElementById('editTestAnalysis').value
        };

        const response = await fetch(`/api/test/${testId}`, {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });

        const result = await response.json();

        if (result.success) {
            showToast('Test updated successfully!');
            bootstrap.Modal.getInstance(document.getElementById('editTestModal')).hide();
            loadTests();
        } else {
            alert('Error: ' + (result.error || 'Failed to update'));
        }
    } catch (error) {
        alert('Network error: ' + error.message);
    } finally {
        document.getElementById('saveTestBtnText').classList.remove('d-none');
        document.getElementById('saveTestBtnSpinner').classList.add('d-none');
        document.getElementById('saveTestBtn').disabled = false;
    }
}

// Summary modal
function openSummaryModal() {
    const modal = new bootstrap.Modal(document.getElementById('summaryModal'));
    modal.show();

    // Reset radio buttons
    document.querySelectorAll('input[name="summaryType"]').forEach(radio => {
        radio.checked = false;
    });

    // Show default message
    document.getElementById('summaryTableBody').innerHTML = `
        <tr>
            <td colspan="20" class="text-center py-5 text-muted">
                <i class="bi bi-info-circle fs-3"></i>
                <div class="mt-2">Select a summary type above to display data</div>
            </td>
        </tr>
    `;

    document.querySelector('#summaryTable thead').innerHTML = '';
}

async function loadEngagementsSummary() {
    try {
        const response = await fetch('/api/summary/engagements');
        const result = await response.json();

        if (result.success) {
            renderEngagementsSummary(result.data, result.col_totals);
        } else {
            showSummaryError(result.error || 'Failed to load engagements summary');
        }
    } catch (error) {
        showSummaryError('Network error: ' + error.message);
    }
}

async function loadJirasSummary() {
    try {
        const response = await fetch('/api/summary/jiras');
        const result = await response.json();

        if (result.success) {
            renderJirasSummary(result.data, result.environments, result.col_totals, result.grand_total);
        } else {
            showSummaryError(result.error || 'Failed to load jiras summary');
        }
    } catch (error) {
        showSummaryError('Network error: ' + error.message);
    }
}

function renderEngagementsSummary(data, colTotals) {
    const thead = document.querySelector('#summaryTable thead');
    thead.innerHTML = `
        <tr>
            <th class="text-center" style="width: 200px;">Lead (Assigned To)</th>
            <th class="text-center">Not Started</th>
            <th class="text-center">In Progress</th>
            <th class="text-center">On Hold</th>
            <th class="text-center fw-bold bg-warning">TOTAL</th>
        </tr>
    `;

    const tbody = document.getElementById('summaryTableBody');

    if (data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center py-3">No data available</td></tr>';
        return;
    }

    let html = '';
    data.forEach(row => {
        html += `
            <tr>
                <td>${row.lead}</td>
                <td class="text-center">${row.not_started}</td>
                <td class="text-center">${row.in_progress}</td>
                <td class="text-center">${row.on_hold}</td>
                <td class="text-center fw-bold bg-warning-subtle">${row.total}</td>
            </tr>
        `;
    });

    // Add total row
    html += `
        <tr class="table-primary fw-bold">
            <td class="text-center">TOTAL</td>
            <td class="text-center">${colTotals.not_started}</td>
            <td class="text-center">${colTotals.in_progress}</td>
            <td class="text-center">${colTotals.on_hold}</td>
            <td class="text-center bg-warning">${colTotals.total}</td>
        </tr>
    `;

    tbody.innerHTML = html;
}

function renderJirasSummary(data, environments, colTotals, grandTotal) {
    const thead = document.querySelector('#summaryTable thead');

    // Create header with sub-columns
    let headerHtml = '<tr><th class="text-center" rowspan="2" style="width: 200px;">Lead</th>';

    environments.forEach(env => {
        headerHtml += `<th class="text-center" colspan="2">${env.name}</th>`;
    });

    headerHtml += '<th class="text-center fw-bold bg-warning" rowspan="2">TOTAL</th></tr>';
    headerHtml += '<tr>';

    environments.forEach(env => {
        headerHtml += '<th class="text-center">Pending</th>';
        headerHtml += '<th class="text-center">On Hold</th>';
    });

    headerHtml += '</tr>';
    thead.innerHTML = headerHtml;

    const tbody = document.getElementById('summaryTableBody');

    if (data.length === 0) {
        tbody.innerHTML = `<tr><td colspan="${(environments.length * 2) + 2}" class="text-center py-3">No data available</td></tr>`;
        return;
    }

    let html = '';
    data.forEach(row => {
        html += `<tr><td>${row.lead}</td>`;

        environments.forEach(env => {
            const pending = row['env_' + env.id + '_pending'] || 0;
            const onhold = row['env_' + env.id + '_onhold'] || 0;
            html += `<td class="text-center">${pending}</td>`;
            html += `<td class="text-center">${onhold}</td>`;
        });

        html += `<td class="text-center fw-bold bg-warning-subtle">${row.total}</td></tr>`;
    });

    // Add total row
    html += '<tr class="table-primary fw-bold"><td class="text-center">TOTAL</td>';

    environments.forEach(env => {
        const pendingTotal = colTotals['env_' + env.id + '_pending'] || 0;
        const onholdTotal = colTotals['env_' + env.id + '_onhold'] || 0;
        html += `<td class="text-center">${pendingTotal}</td>`;
        html += `<td class="text-center">${onholdTotal}</td>`;
    });

    html += `<td class="text-center bg-warning">${grandTotal}</td></tr>`;

    tbody.innerHTML = html;
}
